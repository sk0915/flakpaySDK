package org.flakpay;

public class UPIRequest {

    private String mid;
    private String orderNo;
    private String amount;
    private String currencyName;
    private String type;
    private String email;
    private String mobileNo;
    private String address;
    private String city;
    private String state;
    private String pincode;
    private String trxn_method;
    private String vpa;
    private String customerName;
    private String callbackUrl;
    private String cardNo;
    private String expiryDate;
    private String cvv;
    private String bankCode;
    private String checksum;
    private String customField1;
    private String customField2;
    private String customField3;
    private String customField4;
    private String customField5;
    public void setChecksum(String checksum) {
        this.checksum = checksum;
    }

    public UPIRequest(UPIRequestBuilder UPIRequestBuilder) {
        this.mid = UPIRequestBuilder.mid;
        this.orderNo = UPIRequestBuilder.orderNo;
        this.amount = UPIRequestBuilder.amount;
        this.currencyName = UPIRequestBuilder.currencyName;
        this.type = UPIRequestBuilder.type;
        this.email = UPIRequestBuilder.email;
        this.mobileNo = UPIRequestBuilder.mobileNo;
        this.address = UPIRequestBuilder.address;
        this.city = UPIRequestBuilder.city;
        this.state = UPIRequestBuilder.state;
        this.pincode = UPIRequestBuilder.pincode;
        this.trxn_method = UPIRequestBuilder.trxn_method;
        this.vpa = UPIRequestBuilder.vpa;
        this.customerName = UPIRequestBuilder.customerName;
        this.callbackUrl = UPIRequestBuilder.callbackUrl;
        this.cardNo = UPIRequestBuilder.cardNo;
        this.expiryDate = UPIRequestBuilder.expiryDate;
        this.cvv = UPIRequestBuilder.cvv;
        this.bankCode = UPIRequestBuilder.bankCode;
        this.checksum = UPIRequestBuilder.checksum;
        this.customField1 = UPIRequestBuilder.customField1;
        this.customField2 = UPIRequestBuilder.customField2;
        this.customField3 = UPIRequestBuilder.customField3;
        this.customField4 = UPIRequestBuilder.customField4;
        this.customField5 = UPIRequestBuilder.customField5;
    }



    public String getMid() {
        return mid;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public String getAmount() {
        return amount;
    }

    public String getCurrencyName() {
        return currencyName;
    }

    public String getType() {
        return type;
    }

    public String getEmail() {
        return email;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public String getAddress() {
        return address;
    }

    public String getCity() {
        return city;
    }

    public String getState() {
        return state;
    }

    public String getPincode() {
        return pincode;
    }

    public String getTrxn_method() {
        return trxn_method;
    }

    public String getVpa() {
        return vpa;
    }

    public String getCustomerName() {
        return customerName;
    }

    public String getCallbackUrl() {
        return callbackUrl;
    }

    public String getCardNo() {
        return cardNo;
    }

    public String getExpiryDate() {
        return expiryDate;
    }

    public String getCvv() {
        return cvv;
    }

    public String getBankCode() {
        return bankCode;
    }

    public String getChecksum() {
        return checksum;
    }

//    public String getUrlMode() {
//        return urlMode.toString();
//    }

//    public String getUrl() {
//        return url;
//    }

    public String getCustomField1() {
        return customField1;
    }

    public String getCustomField2() {
        return customField2;
    }

    public String getCustomField3() {
        return customField3;
    }

    public String getCustomField4() {
        return customField4;
    }

    public String getCustomField5() {
        return customField5;
    }
    public enum TransactionType {
        S, P, R;
    }

    public enum TransactionMethod{
        UPI, CARD, NB, WALLET;
    }

//    public enum URLMode{
//        TEST, LIVE;
//    }


    @Override
    public String toString() {
        return "UPIRequest{" +
                "mid=" + mid +
                ", orderNo='" + orderNo + '\'' +
                ", amount='" + amount + '\'' +
                ", currencyName='" + currencyName + '\'' +
                ", type=" + type +
                ", email='" + email + '\'' +
                ", mobileNo='" + mobileNo + '\'' +
                ", address='" + address + '\'' +
                ", city='" + city + '\'' +
                ", state='" + state + '\'' +
                ", pincode='" + pincode + '\'' +
                ", trxn_method=" + trxn_method +
                ", vpa='" + vpa + '\'' +
                ", customerName='" + customerName + '\'' +
                ", callbackUrl='" + callbackUrl + '\'' +
                ", cardNo='" + cardNo + '\'' +
                ", expiryDate='" + expiryDate + '\'' +
                ", cvv='" + cvv + '\'' +
                ", bankCode='" + bankCode + '\'' +
                ", checksum='" + checksum + '\'' +
                ", customField1='" + customField1 + '\'' +
                ", customField2='" + customField2 + '\'' +
                ", customField3='" + customField3 + '\'' +
                ", customField4='" + customField4 + '\'' +
                ", customField5='" + customField5 + '\'' +
                '}';
    }

    public static class UPIRequestBuilder {
        private String mid;
        private String orderNo;
        private String amount;
        private String currencyName;
        private String type;
        private String email;
        private String mobileNo;
        private String address;
        private String city;
        private String state;
        private String pincode;
        private String trxn_method;
        private String vpa;
        private String customerName;
        private String callbackUrl;
        private String cardNo;
        private String expiryDate;
        private String cvv;
        private String bankCode;
        private String checksum;
//        private URLMode urlMode;
//        private String url;
        private String customField1;
        private String customField2;
        private String customField3;
        private String customField4;
        private String customField5;

        public UPIRequestBuilder setMid(String mid) {
            this.mid = mid;
            return this;
        }

        public UPIRequestBuilder setOrderNo(String orderNo) {
            this.orderNo = orderNo;
            return this;
        }

        public UPIRequestBuilder setAmount(String amount) {
            this.amount = amount;
            return this;
        }

        public UPIRequestBuilder setCurrencyName(String currencyName) {
            this.currencyName = currencyName;
            return this;
        }

        public UPIRequestBuilder setType(String type) {
            this.type = type;
            return this;
        }

        public UPIRequestBuilder setEmail(String email) {
            this.email = email;
            return this;
        }

        public UPIRequestBuilder setMobileNo(String mobileNo) {
            this.mobileNo = mobileNo;
            return this;
        }

        public UPIRequestBuilder setAddress(String address) {
            this.address = address;
            return this;
        }

        public UPIRequestBuilder setCity(String city) {
            this.city = city;
            return this;
        }

        public UPIRequestBuilder setState(String state) {
            this.state = state;
            return this;
        }

        public UPIRequestBuilder setPincode(String pincode) {
            this.pincode = pincode;
            return this;
        }

        public UPIRequestBuilder setTrxn_method(String trxn_method) {
            this.trxn_method = trxn_method;
            return this;
        }

        public UPIRequestBuilder setVpa(String vpa) {
            this.vpa = vpa;
            return this;
        }

        public UPIRequestBuilder setCustomerName(String customerName) {
            this.customerName = customerName;
            return this;
        }

        public UPIRequestBuilder setCallbackUrl(String callbackUrl) {
            this.callbackUrl = callbackUrl;
            return this;
        }

        public UPIRequestBuilder setCardNo(String cardNo) {
            this.cardNo = cardNo;
            return this;
        }

        public UPIRequestBuilder setExpiryDate(String expiryDate) {
            this.expiryDate = expiryDate;
            return this;
        }

        public UPIRequestBuilder setCvv(String cvv) {
            this.cvv = cvv;
            return this;
        }

        public UPIRequestBuilder setBankCode(String bankCode) {
            this.bankCode = bankCode;
            return this;
        }

        public UPIRequestBuilder setChecksum(String checksum) {
            this.checksum = checksum;
            return this;
        }

//        public UPIRequestBuilder setUrlMode(URLMode urlMode) {
//            this.urlMode = urlMode;
//            return this;
//        }
//
//        public UPIRequestBuilder setUrl(String url) {
//            this.url = url;
//            return this;
//        }

        public UPIRequestBuilder setCustomField1(String customField1) {
            this.customField1 = customField1;
            return this;
        }

        public UPIRequestBuilder setCustomField2(String customField2) {
            this.customField2 = customField2;
            return this;
        }

        public UPIRequestBuilder setCustomField3(String customField3) {
            this.customField3 = customField3;
            return this;
        }

        public UPIRequestBuilder setCustomField4(String customField4) {
            this.customField4 = customField4;
            return this;
        }

        public UPIRequestBuilder setCustomField5(String customField5) {
            this.customField5 = customField5;
            return this;
        }

        public UPIRequest build() {
            return new UPIRequest(this);
        }
    }
}
