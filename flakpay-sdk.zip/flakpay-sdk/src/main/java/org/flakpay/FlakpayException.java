package org.flakpay;

public class FlakpayException extends Exception{

    public FlakpayException(String message) {
        super(message);
    }
    public FlakpayException() {
        super();
    }
}
