package org.flakpay;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import static org.flakpay.FlakpayHelper.flakpayResponse;


public class FlakpayClient {

    /**
     * To retrieve encryption details
     *
     * @param mode
     * @param encryptedPayload encrypted payload of {@link UPIRequest}
     * @param mid              merchant ID from {@link UPIRequest#getMid()}
     * @return UPIResponse {@link UPIResponse}
     * @throws FlakpayException {@link FlakpayException}
     */
    public static UPIResponse getUPIDetails(FlakpayConnector.Mode mode, String encryptedPayload, String mid) throws FlakpayException {
        return initiateUPIRequest(mode,encryptedPayload, mid);
    }

    /**
     * To require encryptedPayload requires {@link UPIResponse}.
     * @param encryptedPayload to UPIRequest
     * @param mid
     * @return UPIResponse {@link UPIResponse}
     * @throws FlakpayException
     */
    private static UPIResponse initiateUPIRequest(FlakpayConnector.Mode mode,String encryptedPayload, String mid) throws FlakpayException {
    	String modeUrl="";
    	if(FlakpayConnector.Mode.LIVE.equals(mode)) {
    		modeUrl="https://paymentgateway.flakpay.com/paymentGateway/generateQR";
    	}else {
    		modeUrl="http://62.72.56.127/pgflakpay/public/uat/paymentGateway/generateQR";
    	}
        String requestbody = String.format("{\"mid\":\"%s\",\"encryptReq\":\"%s\"}", mid, encryptedPayload);
        String response = apiConnector(modeUrl, requestbody);
        return flakpayResponse(response);

    }

    /**
     *  1. To require encryptedPayload requires: secret key, checksum, algorithm, IV.
     *  2. If condition handle for Live UrL or Test url
     * @param merchantID to get keys
     * @return EncryptionResponse {@link EncryptionResponse} this type return the value
     * @throws FlakpayException
     */
    protected static EncryptionResponse initiateEncryptionRequest(FlakpayConnector.Mode mode, String merchantID) throws FlakpayException {
        String modeUrl = "";
        if(FlakpayConnector.Mode.LIVE.equals(mode)){
        		modeUrl="https://paymentgateway.flakpay.com/fpay/getmerchantConfig";
        }else{
            modeUrl = "http://62.72.56.127/pgflakpay/public/fpay/getmerchantConfig";
        }
        String requestBody = String.format("{\n  \"mid\":\"%s\"\n}", merchantID);
        return extractEncryptionDetails(apiConnector(modeUrl, requestBody));
    }

    private static String apiConnector(String url, String requestBody) throws FlakpayException {
        StringBuilder result = new StringBuilder();
        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            HttpPost httpPost = new HttpPost(url);

            StringEntity requestEntity = new StringEntity(requestBody, StandardCharsets.UTF_8);
            httpPost.setEntity(requestEntity);
            httpPost.setHeader("Content-Type", "application/json");

            CloseableHttpResponse response = httpClient.execute(httpPost);
            HttpEntity responseEntity = response.getEntity();

            if (responseEntity != null) {
                try (BufferedReader reader = new BufferedReader(
                        new InputStreamReader(responseEntity.getContent(), StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        result.append(line);
                    }
                }
            }

        } catch (IOException message) {
            throw new FlakpayException(message.getMessage());
        }

        return result.toString();
    }

    private static EncryptionResponse extractEncryptionDetails(String responseBody) throws FlakpayException {
        Map<String, Object> resultMap = null;
        try {
            resultMap = new ObjectMapper().readValue(responseBody, Map.class);
            String mid = null;
            String secretKey = null;
            String saltKey = null;
            String apiKey = null;
            String checksum = null;
            String algorithm = null;
            String iv = null;

            if (resultMap.containsKey("mid")) {
                mid = (String) resultMap.get("mid");
            }
            if (resultMap.containsKey("sec_key")) {
                secretKey = (String) resultMap.get("sec_key");
            }

            if (resultMap.containsKey("salt_key")) {
                saltKey = (String) resultMap.get("salt_key");
            }
            if (resultMap.containsKey("api_key")) {
                apiKey = (String) resultMap.get("api_key");
            }

            if (resultMap.containsKey("checksum_key")) {
                checksum = (String) resultMap.get("checksum_key");
            }

            if (resultMap.containsKey("algo")) {
                algorithm = (String) resultMap.get("algo");
            }

            if (resultMap.containsKey("iv")) {
                iv = (String) resultMap.get("iv");
            }
            return new EncryptionResponse.Builder()
                    .setMid(mid)
                    .setSecretKey(secretKey)
                    .setSaltKey(saltKey)
                    .setIvVectorKey(iv)
                    .setChecksum(checksum)
                    .build();

        } catch (JsonProcessingException e) {
            throw new FlakpayException(e.toString());
        }
    }

}
