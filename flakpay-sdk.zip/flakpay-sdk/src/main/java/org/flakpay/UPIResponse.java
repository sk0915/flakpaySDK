package org.flakpay;

public class UPIResponse {

    private String responseCode;
    private String message;
    private String objectStatus;
    private String orderStatus;
    private String mid;
    private String upiIntentUrl;
    private String customerName;
    private String orderNo;
    private String address;
    private String city;
    private String mobileNo;
    private String emailId;
    private String state;
    private String pincode;
    private String currencyName;
    private String transactionRefNo;
    private String transactionRefType;
    private String transTime;
    private String paidAmount;
    private String customField1;
    private String customField2;
    private String customField3;
    private String customField4;
    private String customField5;
    private String transactionStatus;
    private String cardNo;
    private String expiryDate;
    private String bankCode;
    private String cvv;

    private UPIResponse(ResponseBuilder builder) {
        this.mid = builder.mid;
        this.upiIntentUrl = builder.upiIntentUrl;
        this.customerName = builder.customerName;
        this.orderNo = builder.orderNo;
        this.address = builder.address;
        this.city = builder.city;
        this.mobileNo = builder.mobileNo;
        this.emailId = builder.emailId;
        this.state = builder.state;
        this.pincode = builder.pincode;
        this.currencyName = builder.currencyName;
        this.transactionRefNo = builder.transactionRefNo;
        this.transactionRefType = builder.transactionRefType;
        this.transTime = builder.transTime;
        this.paidAmount = builder.paidAmount;
        this.customField1 = builder.customField1;
        this.customField2 = builder.customField2;
        this.customField3 = builder.customField3;
        this.customField4 = builder.customField4;
        this.customField5 = builder.customField5;
        this.transactionStatus = builder.transactionStatus;
        this.cardNo = builder.cardNo;
        this.expiryDate = builder.expiryDate;
        this.bankCode = builder.bankCode;
        this.cvv = builder.cvv;
        this.responseCode= builder.responseCode;
        this.message= builder.message;
        this.orderStatus= builder.orderStatus;
        this.objectStatus= builder.objectStatus;


    }

    public String getMessage() {
        return message;
    }

    public String objectStatus() {
        return objectStatus;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public String getResponseCode() {
        return responseCode;
    }

    public String getMid() {
        return mid;
    }

    public String getUpiIntentUrl() {
        return upiIntentUrl;
    }

    public String getCustomerName() {
        return customerName;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public String getAddress() {
        return address;
    }

    public String getCity() {
        return city;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public String getEmailId() {
        return emailId;
    }

    public String getState() {
        return state;
    }

    public String getPincode() {
        return pincode;
    }

    public String getCurrencyName() {
        return currencyName;
    }

    public String getTransactionRefNo() {
        return transactionRefNo;
    }

    public String getTransactionRefType() {
        return transactionRefType;
    }

    public String getTransTime() {
        return transTime;
    }

    public String getPaidAmount() {
        return paidAmount;
    }

    public String getCustomField1() {
        return customField1;
    }

    public String getCustomField2() {
        return customField2;
    }

    public String getCustomField3() {
        return customField3;
    }

    public String getCustomField4() {
        return customField4;
    }

    public String getCustomField5() {
        return customField5;
    }

    public String getTransactionStatus() {
        return transactionStatus;
    }


    public String getCardNo() {
        return cardNo;
    }

    public String getExpiryDate() {
        return expiryDate;
    }

    public String getBankCode() {
        return bankCode;
    }

    public String getCvv() {
        return cvv;
    }


    public static class ResponseBuilder {
        private String responseCode;
        private String message;
        private String objectStatus;
        private String orderStatus;
        private String mid;
        private String upiIntentUrl;
        private String customerName;
        private String orderNo;
        private String address;
        private String city;
        private String mobileNo;
        private String emailId;
        private String state;
        private String pincode;
        private String currencyName;
        private String transactionRefNo;
        private String transactionRefType;
        private String transTime;
        private String paidAmount;
        private String customField1;
        private String customField2;
        private String customField3;
        private String customField4;
        private String customField5;
        private String transactionStatus;
        private String cardNo;
        private String expiryDate;
        private String bankCode;
        private String cvv;



        public ResponseBuilder(String mid, String upiIntentUrl, String customerName, String orderNo) {
            this.mid = mid;
            this.upiIntentUrl = upiIntentUrl;
            this.customerName = customerName;
            this.orderNo = orderNo;
        }

        public ResponseBuilder responseCode(String responseCode) {
            this.responseCode = responseCode;
            return this;
        }
        public ResponseBuilder message(String message) {
            this.message = message;
            return this;
        }
        public ResponseBuilder objectStatus(String objectStatus) {
            this.objectStatus = objectStatus;
            return this;
        }
        public ResponseBuilder orderStatus(String orderStatus) {
            this.orderStatus = orderStatus;
            return this;
        }
        public ResponseBuilder address(String address) {
            this.address = address;
            return this;
        }

        public ResponseBuilder city(String city) {
            this.city = city;
            return this;
        }

        public ResponseBuilder mobileNo(String mobileNo) {
            this.mobileNo = mobileNo;
            return this;
        }

        public ResponseBuilder emailId(String emailId) {
            this.emailId = emailId;
            return this;
        }

        public ResponseBuilder state(String state) {
            this.state = state;
            return this;
        }

        public ResponseBuilder pincode(String pincode) {
            this.pincode = pincode;
            return this;
        }

        public ResponseBuilder currencyName(String currencyName) {
            this.currencyName = currencyName;
            return this;
        }

        public ResponseBuilder transactionRefNo(String transactionRefNo) {
            this.transactionRefNo = transactionRefNo;
            return this;
        }

        public ResponseBuilder transactionRefType(String transactionRefType) {
            this.transactionRefType = transactionRefType;
            return this;
        }

        public ResponseBuilder transTime(String transTime) {
            this.transTime = transTime;
            return this;
        }

        public ResponseBuilder paidAmount(String paidAmount) {
            this.paidAmount = paidAmount;
            return this;
        }

        public ResponseBuilder customField1(String customField1) {
            this.customField1 = customField1;
            return this;
        }

        public ResponseBuilder customField2(String customField2) {
            this.customField2 = customField2;
            return this;
        }

        public ResponseBuilder customField3(String customField3) {
            this.customField3 = customField3;
            return this;
        }

        public ResponseBuilder customField4(String customField4) {
            this.customField4 = customField4;
            return this;
        }

        public ResponseBuilder customField5(String customField5) {
            this.customField5 = customField5;
            return this;
        }

        public ResponseBuilder transactionStatus(String transactionStatus) {
            this.transactionStatus = transactionStatus;
            return this;
        }

        public ResponseBuilder cardNo(String cardNo) {
            this.cardNo = cardNo;
            return this;
        }

        public ResponseBuilder expiryDate(String expiryDate) {
            this.expiryDate = expiryDate;
            return this;
        }

        public ResponseBuilder bankCode(String bankCode) {
            this.bankCode = bankCode;
            return this;
        }

        public ResponseBuilder cvv(String cvv) {
            this.cvv = cvv;
            return this;
        }




        public UPIResponse build() {
            return new UPIResponse(this);
        }
    }
}
