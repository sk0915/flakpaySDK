package org.flakpay;

import org.codehaus.jettison.json.JSONObject;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.security.spec.KeySpec;
import java.util.Base64;
import java.util.TreeMap;

class FlakpayHelper {

	private static String mid;
	private static final String algorithm = "AES/CBC/PKCS5PADDING";
	private static String secretKeyConfig;
	private static String saltKeyConfig;
	private static String checksumKeyConfig;
	private static byte[] ivVectorConfig;

	public static String encrypt(EncryptionResponse flakpayRequest, UPIRequest upiRequest) throws Exception {
		mid = flakpayRequest.getMid();
		secretKeyConfig = flakpayRequest.getSecretKey();
		saltKeyConfig = flakpayRequest.getSaltKey();
		checksumKeyConfig = flakpayRequest.getChecksum();
		ivVectorConfig = flakpayRequest.getIvVectorKey().getBytes();

		TreeMap<String, String> modelObject = new TreeMap<>();
		modelObject.put("mid", upiRequest.getMid());
		modelObject.put("address", upiRequest.getAddress());
		modelObject.put("city", upiRequest.getCity());
		modelObject.put("currency_name", upiRequest.getCurrencyName());
		modelObject.put("custom_field1", upiRequest.getCustomField1());
		modelObject.put("custom_field2", upiRequest.getCustomField2());
		modelObject.put("custom_field3", upiRequest.getCustomField3());
		modelObject.put("custom_field4", upiRequest.getCustomField4());
		modelObject.put("custom_field5", upiRequest.getCustomField5());
		modelObject.put("email", upiRequest.getEmail());
		modelObject.put("mobile_no", upiRequest.getMobileNo());
		modelObject.put("order_no", upiRequest.getOrderNo());
		modelObject.put("amount", upiRequest.getAmount());
		modelObject.put("pincode", upiRequest.getPincode());
		modelObject.put("state", upiRequest.getState());
		modelObject.put("trxn_method", upiRequest.getTrxn_method());
		modelObject.put("type", upiRequest.getType());
		modelObject.put("bank_code", upiRequest.getBankCode());
		modelObject.put("vpa", upiRequest.getVpa());
		modelObject.put("card_no", upiRequest.getCardNo());
		modelObject.put("exp_date", upiRequest.getExpiryDate());
		modelObject.put("cvv", upiRequest.getCvv());
		modelObject.put("customer_name", upiRequest.getCustomerName());
		modelObject.put("callbackUrl", upiRequest.getCallbackUrl());

		if (modelObject != null) {
			upiRequest.setChecksum(FlakpayChecksum.generateSignature(modelObject, checksumKeyConfig, ivVectorConfig));
		}

		return encryptionRequest(upiRequest);
	}

	private static String encryptionRequest(UPIRequest upiRequest) throws FlakpayException {
		StringBuilder concatenatedValues = new StringBuilder();

		Field[] fields = upiRequest.getClass().getDeclaredFields();
		for (Field field : fields) {
			field.setAccessible(true);
			Object value = null;
			try {
				value = field.get(upiRequest);
			} catch (Exception ex) {
				return "issue";
			}
			concatenatedValues.append(value).append('|');
		}
		if (concatenatedValues.length() > 0) {
			concatenatedValues.setLength(concatenatedValues.length() - 1);
		}
		return encrypt(concatenatedValues.toString());
	}

	private static String encrypt(String encryptOnData) throws FlakpayException {
		try {
			SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
			String secretAESKey = secretKeyConfig.concat("000000000000");
			if (secretAESKey.length() == 32) {
				KeySpec spec = new PBEKeySpec(secretAESKey.toCharArray(), saltKeyConfig.getBytes(), 65536, 256);
				SecretKey tmp = factory.generateSecret(spec);
				SecretKey secret = new SecretKeySpec(tmp.getEncoded(), "AES");
				Cipher cipherEncrypt = Cipher.getInstance(algorithm);
				cipherEncrypt.init(Cipher.ENCRYPT_MODE, secret, new IvParameterSpec(ivVectorConfig));
				byte[] encryptedBytes = cipherEncrypt.doFinal(encryptOnData.getBytes(StandardCharsets.UTF_8));
				// Return the Base64-encoded encrypted data
				return Base64.getEncoder().encodeToString(encryptedBytes);
			} else {
				throw new FlakpayException("Secret key length is not exact");
			}
		} catch (Exception ex) {
			throw new FlakpayException(ex.getMessage());
		}
	}

	public static String decrypt(String encodedData) throws Exception {

		try {
			SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
			String secretAESKey = secretKeyConfig.concat("000000000000");
			if (secretAESKey.length() == 32) {
				KeySpec spec = new PBEKeySpec(secretAESKey.toCharArray(), saltKeyConfig.getBytes(), 65536, 256);
				SecretKey tmp = factory.generateSecret(spec);
				SecretKey secret = new SecretKeySpec(tmp.getEncoded(), "AES");
				Cipher cipherDecrypt = Cipher.getInstance(algorithm);
				cipherDecrypt.init(Cipher.DECRYPT_MODE, secret, new IvParameterSpec(ivVectorConfig));
				return new String(cipherDecrypt.doFinal(Base64.getDecoder().decode(encodedData)));

			} else {
				throw new FlakpayException("Secret key length is not exact");
			}
		} catch (Exception ex) {
			throw new FlakpayException(ex.getMessage());
		}
	}

	static UPIResponse flakpayResponse(String fpresponseValue) throws FlakpayException {
		try {
			JSONObject object = new JSONObject(fpresponseValue);

			if (object.get("res_code").equals("FPAY-001") && object.get("status").equals("failed")) {
				throw new FlakpayException("Duplicate order Id found and Try again with a different order Id");
			}

			if (object.get("res_code").equals("FPAY-002")) {
				throw new FlakpayException("Flakpay Service Down");
			}
			if (object.get("res_code").equals("FPAY-003")) {
				throw new FlakpayException("Bad Decryption Error.");
			}
			if (object.get("res_code").equals("FPAY-004")) {
				throw new FlakpayException("Required Input param missing / Invalid request Sequence.");
			}
			if (object.get("res_code").equals("FPAY-005")) {
				throw new FlakpayException("Checksum Validation error.");
			}
			if (object.get("res_code").equals("FPAY-006")) {
				throw new FlakpayException("Unauthorized Request.");
			}

			if (object.get("res_code").equals("FPAY-000") && object.get("status").equals("success")) {

				String beforeDecryptValue = (String) object.get("data");

				String decryptValue = decrypt(beforeDecryptValue);

				String[] splitedValue = decryptValue.split("\\|", 26);
				String checksumHash = splitedValue[3];
				TreeMap<String, String> statusParams = new TreeMap<>();
				TreeMap<String, String> params = new TreeMap<>();

				params.put("mid", splitedValue[0]);
				params.put("upi_intent", splitedValue[1]);
				params.put("address", splitedValue[2]);
				params.put("city", splitedValue[4]);
				params.put("currency_name", splitedValue[5]);
				params.put("customer_name", splitedValue[6]);
				params.put("custom_field1", splitedValue[7]);
				params.put("custom_field2", splitedValue[8]);
				params.put("custom_field3", splitedValue[9]);
				params.put("custom_field4", splitedValue[10]);
				params.put("custom_field5", splitedValue[11]);
				params.put("email", splitedValue[12]);
				params.put("mobile_no", splitedValue[13]);
				params.put("order_no", splitedValue[14]);
				params.put("paid_amount", splitedValue[15]);
				params.put("pincode", splitedValue[16]);
				params.put("state", splitedValue[17]);
				params.put("status", splitedValue[18]);
				params.put("tranx_ref_no", splitedValue[19]);
				params.put("trxn_req_type", splitedValue[20]);
				params.put("trxn_time", splitedValue[21]);
				params.put("card_no", splitedValue[22]);
				params.put("exp_date", splitedValue[23]);
				params.put("bank_code", splitedValue[24]);
				params.put("cvv", splitedValue[25]);

				statusParams.put("responseCode", (String) object.get("res_code"));
				statusParams.put("message", (String) object.get("msg"));
				statusParams.put("objectStatus", (String) object.get("status"));
				statusParams.put("orderStatus", (String) object.get("order_status"));

				boolean isVerifySignature = FlakpayChecksum.verifySignature(params, checksumKeyConfig, checksumHash);

				if (isVerifySignature) {
					return new UPIResponse.ResponseBuilder(params.get("mid"), params.get("upi_intent"),
							params.get("customer_name"), params.get("order_no"))
							
							.address(params.get("address"))
							.city(params.get("city")).currencyName(params.get("currency_name"))
							.customField1(params.get("custom_field1")).customField2(params.get("custom_field2"))
							.customField3(params.get("custom_field3")).customField4(params.get("custom_field4"))
							.customField5(params.get("custom_field5"))
							.bankCode(params.get("bank_code")).cardNo(params.get("card_no"))
							.emailId(params.get("email")).mobileNo(params.get("mobile_no")).cvv(params.get("cvv"))
							.expiryDate(params.get("exp_date")).paidAmount(params.get("paid_amount"))
							.pincode(params.get("pincode")).state(params.get("state"))
							.transactionRefNo(params.get("tranx_ref_no"))
							.transactionRefType(params.get("trxn_req_type")).transTime(params.get("trxn_time"))
							.transactionStatus(params.get("status"))
							.responseCode(statusParams.get("responseCode"))
							.objectStatus(statusParams.get("objectStatus")).message(statusParams.get("message"))
							.orderStatus(statusParams.get("orderStatus")).build();

				} else {
					throw new FlakpayException("Checksum Validation error");
				}
			}
		} catch (Exception e) {
			throw new FlakpayException(e.getMessage());
		}
		return null;
	}
}
