package org.flakpaySDK;

import java.util.Arrays;

/*
* This class contains the request validations, encryption and decryption logic.
*/
public class FlakpayConnector {

    private final Mode mode;
    private final UPIRequest upiRequest;
    private static FlakpayConnector instance;

    FlakpayConnector(String mode, UPIRequest upiRequest) throws FlakpayException {
        Arrays.stream(Mode.values()).filter(e -> e.equals(Mode.valueOf(mode.toUpperCase())))
                .findFirst()
                .orElseThrow(() ->new FlakpayException("Please check your mode"));
        checkUPIProperties(upiRequest);
        this.upiRequest = upiRequest;
        this.mode = Mode.valueOf(mode.toUpperCase());
    }

    /**
     * Get this instance to connect with server
     * @param upiRequest this param through to request model {@link UPIRequest}
     * @return instance FlakpayConnector(upiRequest)
     * @throws FlakpayException
     */
    public static FlakpayConnector getInstance(String mode, UPIRequest upiRequest) throws FlakpayException {
        if (instance == null) {
            instance = new FlakpayConnector(mode, upiRequest);
        }
        return instance;
    }

    public static FlakpayConnector getCurrentInstance() throws FlakpayException {
        if (instance == null) {
            throw new FlakpayException("No instance has been initialized.");
        }
        return instance;
    }

    public UPIResponse getUPI() throws FlakpayException ,Exception {
        return getUPIResponse();
    }

    protected static UPIResponse getUPIResponse() throws Exception {
        EncryptionResponse clientEncryptionResponse = FlakpayClient.initiateEncryptionRequest(getCurrentInstance().mode, getCurrentInstance().upiRequest.getMid());
        String encryptedPayload = FlakpayHelper.encrypt(clientEncryptionResponse,getCurrentInstance().upiRequest) ;
        return FlakpayClient.getUPIDetails(getCurrentInstance().mode, encryptedPayload, getCurrentInstance().upiRequest.getMid());
    }

    static boolean isNull(Object value) throws FlakpayException {
        return (value == null );
    }

    private void checkUPIProperties(UPIRequest upiRequest) throws FlakpayException {
        if (isNull(upiRequest.getMid())) {
            throw new FlakpayException("Merchant id not found or empty");
        }

        if (isNull(upiRequest.getOrderNo())) {
            throw new FlakpayException("Order number not found or empty");
        }

        if (isNull(upiRequest.getAmount())) {
            throw new FlakpayException("Amount is not found or empty");
        }

        if (isNull(upiRequest.getCurrencyName())) {
            throw new FlakpayException("Currency name is not found or empty");
        }

        if (upiRequest.getType().isEmpty()) {
            throw new FlakpayException("Transaction type is not found or empty");
        }

        if (isNull(upiRequest.getEmail())) {
            throw new FlakpayException("Email is not found or empty");
        }

        if (isNull(upiRequest.getMobileNo())) {
            throw new FlakpayException("Mobile number is not found or empty");
        }

        if (isNull(upiRequest.getAddress())) {
            throw new FlakpayException("Address is not found or empty");
        }

        if (isNull(upiRequest.getCity())) {
            throw new FlakpayException("City is not found or empty");
        }

        if (isNull(upiRequest.getState())) {
            throw new FlakpayException("State is not found or empty");
        }

        if (isNull(upiRequest.getPincode())) {
            throw new FlakpayException("Pincode is not found or empty");
        }

        if (upiRequest.getTrxn_method().isEmpty()) {
            throw new FlakpayException("Transaction method is not found or empty");
        }
        
        if (isNull(upiRequest.getCustomerName())) {
            throw new FlakpayException("Customer name is not found or empty");
        }

        if (isNull(upiRequest.getCallbackUrl())) {
            throw new FlakpayException("Callback URL is not found or empty");
        }
        
        if (isNull(upiRequest.getVpa())) {
            throw new FlakpayException("VPA is not found or empty");
        }
        
        if(isNull(upiRequest.getCardNo())){
            throw new FlakpayException("If the card number is not used then set empty string");
        }

        if(isNull(upiRequest.getExpiryDate())){
            throw new FlakpayException("If the expiry date is not used then set empty string");
        }

        if(isNull(upiRequest.getCvv())){
            throw new FlakpayException("If the cvv number is not used then set empty string");
        }

        if(isNull(upiRequest.getBankCode())){
            throw new FlakpayException("If the bank code is not used then set empty string");
        }

        if (isNull(upiRequest.getCustomField1())) {
            throw new FlakpayException("If the cvv number is not used then set empty string");
        }

        if (isNull(upiRequest.getCustomField2())) {
            throw new FlakpayException("If the cvv number is not used then set empty string");
        }

        if (isNull(upiRequest.getCustomField3())) {
            throw new FlakpayException("If the cvv number is not used then set empty string");
        }

        if (isNull(upiRequest.getCustomField4())) {
            throw new FlakpayException("If the cvv number is not used then set empty string");
        }

        if (isNull(upiRequest.getCustomField5())){
            throw new FlakpayException("If the cvv number is not used then set empty string");
        }

    }

    enum Mode{
        LIVE,
        TEST;
    }
}
