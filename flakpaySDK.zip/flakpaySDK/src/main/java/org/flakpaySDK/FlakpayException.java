package org.flakpaySDK;

public class FlakpayException extends Exception{

    public FlakpayException(String message) {
        super(message);
    }
    public FlakpayException() {
        super();
    }
}
