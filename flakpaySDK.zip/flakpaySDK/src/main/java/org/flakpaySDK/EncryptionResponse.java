package org.flakpaySDK;

class EncryptionResponse {
    private final String mid;
    private final String secretKey;
    private final String saltKey;
    private final String ivVectorKey;
    private final String checksum;

    public String getMid() {
        return mid;
    }

    public String getSecretKey() {
        return secretKey;
    }

    public String getSaltKey() {
        return saltKey;
    }

    public String getIvVectorKey() {
        return ivVectorKey;
    }

    public String getChecksum() {
        return checksum;
    }

    public EncryptionResponse(Builder builder) {
        this.mid = builder.mid;
        this.secretKey = builder.secretKey;
        this.saltKey = builder.saltKey;
        this.ivVectorKey = builder.ivVectorKey;
        this.checksum = builder.checksum;
    }


    public static class Builder{
        private String mid;
        private String secretKey;
        private String saltKey;
        private String ivVectorKey;
        private String checksum;

        public Builder setMid(String merchantID) {
            this.mid = merchantID;
            return this;
        }

        public Builder setSecretKey(String secretKey) {
            this.secretKey = secretKey;
            return this;
        }

        public Builder setSaltKey(String saltKey) {
            this.saltKey = saltKey;
            return this;
        }

        public Builder setIvVectorKey(String ivVectorKey) {
            this.ivVectorKey = ivVectorKey;
            return this;
        }

        public Builder setChecksum(String checksum) {
            this.checksum = checksum;
            return this;
        }

        public EncryptionResponse build() {
            return new EncryptionResponse(this);
        }
    }
}
